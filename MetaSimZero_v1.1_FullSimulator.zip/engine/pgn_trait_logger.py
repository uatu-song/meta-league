
# pgn_trait_logger.py
def log_trait_event(pgn_log, turn, actor, trait_name, result, cost):
    '''
    Appends a formatted trait log to the PGN or HTML commentary list.
    '''
    note = f"{actor} activates {trait_name} → {result} (STA -{cost})"
    entry = {
        "turn": turn,
        "actor": actor,
        "type": "trait",
        "text": note
    }
    pgn_log.append(entry)
