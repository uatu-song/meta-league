import csv
import os
from metaChess.utils.paths import get_data_path
from metaChess.utils.pgn_trait_logger import log_trait_event

TRAIT_TYPES = {
    "Passive": 1,
    "Triggered": 3,
    "Active": 5,
    "Manual": 2,
    "Limited": 2,
    "Circuit": 0,
    "Synergy": 0
}

TRAIT_KEY_ALIASES = {
    "hpRegen": "HP",
    "defBoost": "RES",
    "critChance": "FS",
    "moraleBoost": "Morale",
    "psyBoost": "WIL",
    "speedUp": "SPD"
}

class TraitEngine:
    def __init__(self, csv_path: str = None):
        if csv_path is None:
            base_dir = os.path.dirname(__file__)
            default_path = os.path.join(base_dir, "..", "data", "trait_catalog_v5.csv")
            csv_path = os.path.abspath(default_path)
        self.catalog = self.load_traits_from_spreadsheet(csv_path)

    def load_traits_from_spreadsheet(self, csv_path: str):
        trait_catalog = {}
        with open(csv_path, mode="r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                triggers_list = row.get("triggers", "").split(";") if row.get("triggers") else []
                bound_ids_list = row.get("bound_nbid", "").split(";") if row.get("bound_nbid") else []
                triggers_list = [t.strip() for t in triggers_list]
                bound_ids_list = [b.strip() for b in bound_ids_list]

                trait_data = {
                    "trait_id": row.get("trait_id", ""),
                    "name": row.get("name", ""),
                    "type": row.get("type", "Passive"),
                    "triggers": triggers_list,
                    "formula": {
                        "key": row.get("formula_key", ""),
                        "expression": row.get("formula_expr", "")
                    },
                    "bound_to": bound_ids_list,
                    "stamina_cost": int(float(row.get("stamina_cost", 0))) if row.get("stamina_cost") else 0,
                    "cooldown": row.get("cooldown", "none"),
                    "description": row.get("description", "")
                }
                trait_catalog[trait_data["trait_id"]] = trait_data
        return trait_catalog

    def get_traits_for_character(self, nbid: str):
        return [trait for trait in self.catalog.values() if nbid in trait.get("bound_to", [])]

    def run(self, context, turn_data, actor_nbid, trigger_phase):
        actor = context.characters.get(actor_nbid, {})
        stats = actor.get("stats", {})
        notes = []
        traits = self.get_traits_for_character(actor_nbid)

        for trait in traits:
            if trigger_phase not in trait.get("triggers", []):
                continue

            trait_type = trait.get("type", "Passive")
            cost = trait.get("stamina_cost", TRAIT_TYPES.get(trait_type, 1))
            if stats.get("STA", 0) < cost:
                continue

            formula = trait.get("formula", {})
            key = formula.get("key", "")
            expr = formula.get("expression", "")
            stat_key = TRAIT_KEY_ALIASES.get(key, key)

            if key == "multi":
                sub_expressions = expr.split(";")
                for sub_expr in sub_expressions:
                    sub_expr = sub_expr.strip()
                    if not sub_expr or "+" not in sub_expr:
                        continue
                    try:
                        local_vars = stats.copy()
                        value = eval(sub_expr, {}, local_vars)
                        sub_key = sub_expr.split("+")[0].strip()
                        pre_val = stats.get(sub_key, 0)
                        stats[sub_key] = pre_val + value
                        msg = f"{trait['name']} → {sub_key}+{round(value, 2)} (STA -{cost})"
                        notes.append(msg)
                        log_trait_event(turn_data.setdefault("log", []), turn_data.get("turn", 0), actor_nbid, trait['name'], f"{sub_key}+{round(value, 2)}", cost)
                    except Exception as e:
                        notes.append(f"{trait['name']} multi error: {e}")
                stats["STA"] = stats.get("STA", 0) - cost
                continue

            try:
                local_vars = stats.copy()
                value = eval(expr, {}, local_vars) if expr and stat_key else 0
                pre_val = stats.get(stat_key, 0)
                stats[stat_key] = pre_val + value
                stats["STA"] = stats.get("STA", 0) - cost
                msg = f"{trait['name']}: {stat_key} {pre_val}->{stats[stat_key]} (STA -{cost})"
                notes.append(msg)
                log_trait_event(turn_data.setdefault("log", []), turn_data.get("turn", 0), actor_nbid, trait['name'], f"{stat_key}+{round(value, 2)}", cost)
            except Exception as e:
                notes.append(f"{trait['name']} formula error: {e}")
                log_trait_event(turn_data.setdefault("log", []), turn_data.get("turn", 0), actor_nbid, trait['name'], f"FAILED: {e}", 0)

        if notes:
            turn_data.setdefault("notes", []).extend(notes)
