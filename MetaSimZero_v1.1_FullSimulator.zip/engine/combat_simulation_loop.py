# /mnt/data/combat_simulation_loop.py

import json
import random
from pathlib import Path

# --- Load profiles ---
def load_profile(path):
    with open(path) as f:
        return json.load(f)

# --- Vanguard Role Engine Logic ---
def modify_hit_chance(attacker, defender, base_hit):
    if defender.get("role") == "enforcer":
        return base_hit + 5
    if attacker.get("role") == "ghostoperative":
        return base_hit - 10
    if attacker.get("role") == "ranger":
        return base_hit - 10
    return base_hit

# --- Psioperative stamina cost only ---
def apply_role_ability(attacker, defender, damage):
    if attacker.get("role") == "psioperative":
        attacker["CurrentSTA"] = max(0, attacker["CurrentSTA"] - 5)
    return damage

# --- Enforcer defense ability ---
def apply_defense_logic(defender, damage):
    if defender.get("role") == "enforcer" and damage > 0:
        blocked = min(damage, 5)
        return damage - blocked
    if defender.get("role") == "ranger" and random.random() < 0.2:
        return 0
    return damage

# --- Cap Ranger damage ---
def cap_ranger_damage(attacker, damage):
    if attacker.get("role") == "ranger":
        return min(damage, 18)
    return damage

# --- Track assists ---
def track_assist(attacker, defender):
    if "assist_tags" not in defender:
        defender["assist_tags"] = []
    defender["assist_tags"].append(attacker["role"])

# --- Synergy Calculation ---
def calculate_synergy(team_profiles):
    ldr_values = [p.get("LDR", 0) for p in team_profiles if p.get("HP", 1) > 0]
    if not ldr_values:
        return 1.0
    avg_ldr = sum(ldr_values) / len(ldr_values)
    max_ldr = max(ldr_values)
    synergy = 1 + (avg_ldr * 0.02) + (max_ldr / 50)
    return round(synergy, 2)

# --- Morale Calculation ---
def calculate_morale(team_profiles, base, casualties, event_mod):
    alive_profiles = [p for p in team_profiles if p.get("HP", 0) > 0]
    if not alive_profiles:
        return 0
    ldr_mod = sum(p.get("LDR", 0) for p in alive_profiles) // len(alive_profiles)
    morale = base + ldr_mod - casualties + event_mod
    return round(morale, 2)

# --- Initialize Combatant ---
def initialize_hp(profile):
    profile["HP"] = int(profile.get("HP", 100) * 1.3)  # Reduced from 1.5 to 1.3
    profile["CurrentSTA"] = profile.get("CurrentSTA", profile.get("MaxSTA", 100))
    profile["XP"] = 0
    profile["log"] = []
    profile["assist_tags"] = []
    profile["expression"] = profile.get("expression", profile.get("role"))
    profile["SPD"] = profile.get("SPD", 10)
    profile["FS"] = profile.get("FS", 10)
    return profile

# --- Simulate Action ---
def simulate_action(attacker, defender, synergy_mod=1.0, morale_mod=0, round_num=1, defender_is_team2=False):
    STR = attacker.get("STR", 0)
    FS = attacker.get("FS", 0)
    SPD = attacker.get("SPD", 0)
    base_acc = attacker.get("BaseAccuracy", 0)
    evasion = defender.get("Evasion", 0)

    base_hit = base_acc + ((FS + STR) / 2 * 0.02) - evasion
    final_hit = base_hit * synergy_mod + morale_mod * 0.1
    final_hit = max(0, min(100, final_hit))

    roll = random.uniform(0, 100)
    hit = roll < final_hit

    damage = 0
    narrative = "misses"
    if hit:
        base = 10
        str_mult = 1.5
        bonus = 3
        max_sta = attacker.get("MaxSTA", 100)
        curr_sta = attacker.get("CurrentSTA", 100)
        sta_ratio = curr_sta / max_sta if max_sta > 0 else 1.0
        damage = (base + STR * str_mult + bonus) * sta_ratio
        damage = cap_ranger_damage(attacker, damage)
        damage = apply_role_ability(attacker, defender, damage)
        damage = apply_defense_logic(defender, damage)
        if round_num == 1 and defender_is_team2:
            damage *= 0.85  # Reduced brace effect from 25% to 15%

        if defender["HP"] > 0:
            track_assist(attacker, defender)

        defender["HP"] = max(0, defender.get("HP", 100) - damage)
        attacker["CurrentSTA"] = max(0, curr_sta - 10)
        attacker["XP"] += int(damage / 2)
        narrative = f"hits for {damage:.2f} damage"

    attacker["log"].append(f"Round: {attacker['expression']} attacks {defender['expression']} and {narrative}.")

    return {
        "attacker": attacker["expression"],
        "defender": defender["expression"],
        "hitChance": round(final_hit, 2),
        "roll": round(roll, 2),
        "result": "Hit" if hit else "Miss",
        "damage": damage,
        "remainingSTA": attacker["CurrentSTA"],
        "defenderHP": defender["HP"]
    }

# --- Battle Loop with Mid-Round + End-Round Morale ---
def run_single_battle(team1_profiles, team2_profiles):
    team1 = [initialize_hp(p.copy()) for p in team1_profiles]
    team2 = [initialize_hp(p.copy()) for p in team2_profiles]
    base_morale1 = 50
    base_morale2 = 50
    round_num = 1

    while any(p["HP"] > 0 for p in team1) and any(p["HP"] > 0 for p in team2) and round_num <= 15:
        synergy1 = calculate_synergy(team1)
        synergy2 = calculate_synergy(team2)
        casualties1 = sum(1 for p in team1 if p["HP"] <= 0)
        casualties2 = sum(1 for p in team2 if p["HP"] <= 0)
        morale1 = calculate_morale(team1, base_morale1, casualties1, event_mod=3)
        morale2 = calculate_morale(team2, base_morale2, casualties2, event_mod=3)

        all_combatants = [p for p in team1 + team2 if p["HP"] > 0]
        for unit in all_combatants:
            unit["initiative"] = unit.get("SPD", 10) + unit.get("FS", 10) + random.uniform(0, 10)

        random.shuffle(all_combatants)
all_combatants.sort(key=lambda x: (x["initiative"], random.random()), reverse=True)

        deferred_casualties1 = 0
        deferred_casualties2 = 0

        alternating = [t for t in all_combatants if t in team1] + [t for t in all_combatants if t in team2]
        if round_num % 2 == 0:
            alternating = alternating[::-1]  # Team 2 goes first on even rounds
        # Simultaneous resolution phase
        attacker_results = []
        for attacker in alternating:
            if attacker["HP"] <= 0:
                continue
            enemies = team2 if attacker in team1 else team1
            synergy = synergy1 if attacker in team1 else synergy2
            morale = morale1 if attacker in team1 else morale2
            is_team2 = attacker in team2

            available_targets = [e for e in enemies if e["HP"] > 0]
            if not available_targets:
                continue

            defender = random.choice(available_targets)
            pre_HP = defender["HP"]
            result = simulate_action(attacker, defender, synergy, morale, round_num, defender in team2)
            attacker_results.append((attacker, defender, result, pre_HP))

        # Apply deferred morale and KO tracking
        for attacker, defender, result, pre_HP in attacker_results:
            if defender["HP"] <= 0 and pre_HP > 0:
                if defender in team1:
                    base_morale1 -= 2
                    deferred_casualties1 += 1
                else:
                    base_morale2 -= 2
                    deferred_casualties2 += 1

        base_morale1 -= deferred_casualties1 * 3
        base_morale2 -= deferred_casualties2 * 3

        round_num += 1

    return "Team 1" if any(p["HP"] > 0 for p in team1) else "Team 2"
