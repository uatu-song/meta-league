# 📘 META League LLM Manual

## 🔢 Formula Reference
### 1. Mission/Action Success
- **Formula:** `= (Stat1 + Stat2/10 + TMod + RAND())`
- **Where Used:** Probability Tab (SimEngine v3)
- **Purpose:** Determines outcome of mission checks, stealth rolls, tactical actions

### 2. Hit Chance Calculation
- **Formula:** `= BaseAccuracy + ((FS + STR)/2 * 0.02) - Evasion`
- **Where Used:** Attack Tab
- **Purpose:** Determines whether an attack hits or misses

### 3. Damage Dealt
- **Formula:** `= (Base + STR*m + Bonus) * (Current STA / Max STA)`
- **Where Used:** Damage Tab
- **Purpose:** Final damage output calculation after hit

### 4. Morale System
- **Formula:** `= Base + Outcome + Leadership Modifier - Casualties + Event`
- **Where Used:** Morale Tab
- **Purpose:** Teamwide morale effect on damage, cohesion, and synergy

### 5. AM Growth Calculation
- **Formula:** `= Base Increase * ((1 + AM/10) * (1 + Success Factor))`
- **Where Used:** AM Change Tab
- **Purpose:** Governs stat advancement based on Adaptive Mastery and performance

### 6. Stability Adjustment
- **Formula:** `= Old SBY + (Env + Performance + Recovery)`
- **Where Used:** Stability Tab
- **Purpose:** Long-term reliability and risk tracking for Nexus Being

### 7. Synergy Modifier
- **Formula:** `= 1 + (Average LDR * 0.02) + (Max LDR / 50)`
- **Where Used:** Synergy Tab
- **Purpose:** Applies team coordination and leadership bonus

## 🗂️ Sheet Layout Reference
### Attribute Stats
- **Key Columns:** A:P
- **Main Fields:** INT, STR, SPD, DUR, EP, FS, LDR, RES, WIL, LCK, ESP, OP, AM, SBY
- **Purpose:** Stores core aStats for each Nexus Being. Used in all stat-driven formulas.

### Master Roster
- **Key Columns:** A:AF
- **Main Fields:** NBID, Team, Role, Tags, Mobility, Photo, Archetype
- **Purpose:** Maps each Nexus Being to teams, tags, roles, and roster metadata.

### Initiate
- **Key Columns:** A:N
- **Main Fields:** Alpha, FS, Initiative Score, Actions, Opponent Sim
- **Purpose:** Determines order of action and number of actions per round.

### Attack
- **Key Columns:** A:I
- **Main Fields:** STR, FS, Base Accuracy, Evasion, Hit %, Result
- **Purpose:** Calculates hit chance and logs attack outcomes.

### Damage
- **Key Columns:** A:M
- **Main Fields:** Base Damage, STR, EP, Resist, STA Ratio
- **Purpose:** Computes damage values for both physical and energy attacks.

### Stamina
- **Key Columns:** A:H
- **Main Fields:** STA Rating, Action Cost, Current STA, Performance Modifier
- **Purpose:** Tracks stamina consumption and determines if a character is benched.

### Morale
- **Key Columns:** A:G
- **Main Fields:** Base Morale, Outcome Modifier, Casualty Penalty, Final Score
- **Purpose:** Calculates team morale and its effect on performance.

### Synergy
- **Key Columns:** A:F
- **Main Fields:** Average LDR, Highest LDR, Specialist Bonus, Total Score
- **Purpose:** Applies synergy bonus based on team leadership and tag logic.

### AM Change
- **Key Columns:** A:I
- **Main Fields:** AM, Success Factor, Growth Factor, Improvement Amount
- **Purpose:** Stat growth logic using Adaptive Mastery (AM) and performance.

### Stability
- **Key Columns:** A:I
- **Main Fields:** Old Stability, Environmental Mod, Training Bonus
- **Purpose:** Evaluates long-term control/instability in characters.

### Probability
- **Key Columns:** A:J
- **Main Fields:** Mission Steps, Required Stats, Terrain Mod, Threshold
- **Purpose:** Handles all scenario-based stat checks during missions.

