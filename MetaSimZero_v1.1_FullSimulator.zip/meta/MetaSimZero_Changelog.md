
# 🧾 MetaSimZero Changelog

## Version 1.0 (MetaSimZero)
**Date:** 2025-04-15

### 🔧 Core Engine Features
- Fully unbiased battle loop (no "Team1" bias)
- Trait engine integration (`OnStartTurn`, `multi`, etc.)
- Stamina tracked + impacts performance
- HP/STA carryover between days
- KO → Injury (IR) with 7-day cooldown or healing

### ⚔️ Simulation Upgrades
- 45-match round robin run across 10 teams
- All characters active (0% inactivity rate)
- INT added to trait expressions and action logic
- Trait cooldowns deprecated in favor of STA logic

### ⚠️ Death Rules Introduced
- KO @ 0 STA = 20% death chance
- Chaos kill via SBY-scaled random chance (1–3%)
- Self-sacrifice = guaranteed death

### 💉 Healing & Recovery
- Elixir = full team revive
- Healer trait = STA-based individual revival

### 🩸 Fatigue Scaling
- STA impacts INT, RES, SBY directly
- Characters with low STA perform worse

---

## Planned for MetaSimZero 1.1
- Remove all `cooldown` trait logic
- Trait usage governed purely by STA + role + INT
- Auto-weekly reset system
- Trait-based targeting AI (INT-weighted)
- Death logging into `graveyard.json`
- Character state manager (`character_state.json`)
- Adjust hit chance tuning:
  - Raise STR/FS weight
  - Slightly reduce EVS penalty
  - Add INT-based accuracy mod
  - Role-based accuracy profiles
