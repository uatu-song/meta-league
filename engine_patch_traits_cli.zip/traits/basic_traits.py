
"""Sample trait implementations ready to register with TraitEngine."""

from event_bus import bus

class TraitBase:
    trigger_phase = 'before_action'
    id = 'base'

    def __call__(self, **ctx):
        pass

class TactileMimicry(TraitBase):
    id = 'tactile_mimicry'
    trigger_phase = 'before_action'

    def __call__(self, actor=None, target=None, **_):
        if target:
            actor.aStats = target.aStats.copy()

class SynchronicAlignment(TraitBase):
    id = 'synchronic_alignment'
    trigger_phase = 'round_start'

    def __call__(self, actor=None, allies=None, **_):
        if not allies: return
        # copy highest stat among adjacent allies
        best = max((max(a.aStats.values()) for a in allies), default=0)
        if best:
            key = max(actor.aStats, key=lambda k: actor.aStats[k])
            actor.aStats[key] = best

class ProbabilityShift(TraitBase):
    id = 'probability_shift'
    trigger_phase = 'after_action'

    def __init__(self):
        self.used_round = -1

    def __call__(self, actor=None, result=None, round_num=None, **_):
        if result == 'fail' and self.used_round != round_num:
            # convert to success once per round
            self.used_round = round_num
            actor.band = 'Accurate'

class LeadershipAura(TraitBase):
    id = 'leadership_aura'
    trigger_phase = 'round_start'

    def __call__(self, actor=None, team=None, **_):
        for mate in team:
            mate.roll_bonus += 2
