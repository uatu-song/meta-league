
#!/usr/bin/env python3
"""Run all matchups for a given date using engine modules."""

import argparse, json, os, uuid
from hero import Hero
from combat_loop import simulate_match
from boxscore_serializer import write_boxscores
from regen_manager import regenerate
from trait_engine import TraitEngine

def build_heroes(lineup_path, trait_catalog):
    with open(lineup_path) as f:
        data = json.load(f)
    engine = TraitEngine()
    engine.load_from_catalog(trait_catalog)
    heroes = []
    for team in data['teams']:
        for slot, meta in team['slots'].items():
            h = Hero(meta)
            h.teamId = team['teamId']
            heroes.append(h)
    return heroes

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--lineup', required=True, help='lineup json file')
    ap.add_argument('--out', default='output', help='output dir')
    args = ap.parse_args()

    with open('trait_catalog.json') as f:
        catalog = json.load(f)

    heroes = build_heroes(args.lineup, catalog)
    match_id = str(uuid.uuid4())[:8]
    simulate_match(heroes)
    outdir = os.path.join(args.out, args.lineup.split('/')[-1].split('.')[0])
    write_boxscores(match_id, heroes, outdir)

    # sample morale dict
    team_morale = {}
    regenerate(heroes, team_morale)

if __name__ == '__main__':
    main()
