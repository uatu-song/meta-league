
from typing import Protocol, Dict
from importlib import import_module
from event_bus import bus

class TraitProtocol(Protocol):
    trigger_phase: str
    id: str
    def __call__(self, **kwargs): ...

class TraitEngine:
    """Loads trait classes by id and registers them to event bus."""

    def __init__(self):
        self._traits: Dict[str,TraitProtocol] = {}

    def load_from_catalog(self, catalog: Dict[str,str]):
        """catalog maps trait_id -> 'module:ClassName' path"""
        for tid, path in catalog.items():
            mod_name, cls_name = path.split(':')
            mod = import_module(mod_name)
            cls = getattr(mod, cls_name)
            self.register(cls())

    def register(self, trait: TraitProtocol):
        self._traits[trait.id] = trait
        bus.subscribe(trait.trigger_phase, trait)
