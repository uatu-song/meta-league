# simulate_night.py

from engines.synergy_engine import calculate_synergy_bonuses
from engines.morale_engine import adjust_team_morale
from engines.stamina_engine import apply_stamina_changes
from engines.aar_engine import generate_aar, save_aar_report
from engines.stat_engine import compute_rstats
from engines.trait_engine import apply_traits
from utils.file_utils import load_json, save_json, ensure_dirs
import os
import json
import random

def simulate_night():
    print("🚀 Simulator started...")
    ensure_dirs(["results", "trackers", "narratives"])

    # 1) Load lineups, synergy data, environment, etc.
    lineups = load_json("data/lineups.json")           
    synergy_tags = load_json("data/synergy_tags.json")
    synergy_rules = load_json("data/synergy_rules.json")
    trait_data = load_json("data/numb_traits.json")

    environment = "dark_dimension"

    # 2) Calculate synergy bonuses
    apply_traits(lineups, trait_data)
    synergy_map = calculate_synergy_bonuses(lineups, synergy_tags, synergy_rules, environment)

    # 3) Simulate match
    team_names = list(lineups.keys())
    if len(team_names) < 2:
        print("❌ Not enough teams for a matchup!")
        print("Not enough teams for a matchup!")
        return

    teamA, teamB = team_names[0], team_names[1]
    teamA_bonus = synergy_map[teamA]["total_dice_bonus"]
    teamB_bonus = synergy_map[teamB]["total_dice_bonus"]

    rollA = random.randint(1, 20) + teamA_bonus
    rollB = random.randint(1, 20) + teamB_bonus

    winning_team = teamA if rollA > rollB else teamB
    losing_team = teamB if winning_team == teamA else teamA

    # 4) Build log
    sim_logs = [
        {
            "attacker": teamA + "_combined",
            "defender": teamB + "_combined",
            "final_score": rollA,
            "result": "Victory" if winning_team == teamA else "Loss",
            "synergy_bonus": teamA_bonus
        },
        {
            "attacker": teamB + "_combined",
            "defender": teamA + "_combined",
            "final_score": rollB,
            "result": "Victory" if winning_team == teamB else "Loss",
            "synergy_bonus": teamB_bonus
        }
    ]

    # 5) Morale
    adjust_team_morale([
        {"winning_team": winning_team, "losing_team": losing_team}
    ], "data/team_morale.json", win_change=2, loss_change=-2)

    # 6) Stamina
    apply_stamina_changes(winning_team, losing_team, lineups, "data/stamina.json", base_fatigue=3, victory_bonus=1)

    # 7) AAR
    aar_text = generate_aar(sim_logs, winning_team, losing_team, environment)
    save_aar_report(aar_text, output_path="narratives/Full_Mission_AAR.txt")

    # 8) rStats
    rstats = compute_rstats(teamA, teamB, sim_logs)
    os.makedirs("results", exist_ok=True)
    with open(f"results/rstats_{teamA}_vs_{teamB}.json", "w") as f:
        json.dump(rstats, f, indent=2)

        print("Loaded lineups:", lineups)
    print("Synergy bonuses:", synergy_map)
    print("Roll A:", rollA, "Roll B:", rollB)
    print("Sim logs:", sim_logs)
    print("Winner:", winning_team)
    print("rStats:", rstats)
    print("Night simulation complete. AAR and stats saved.")
    print("Loaded lineups:", lineups)
    print("Synergy map:", synergy_map)
    print("Sim logs:", sim_logs)
    print("rStats:", rstats)

if __name__ == "__main__":
    simulate_night()
