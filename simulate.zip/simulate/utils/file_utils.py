import os
import json

def load_json(path):
    with open(path, 'r') as f:
        return json.load(f)

def save_json(path, data):
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)

def ensure_dirs(dir_list):
    for d in dir_list:
        os.makedirs(d, exist_ok=True)