# stat_engine.py

import random

def compute_rstats(teamA_name, teamB_name, logs):
    """
    Returns a dict of per-character rStats.
    Uses simplified logic for testing.
    """
    stats = {}

    # Collect basic per-team data from logs
    for entry in logs:
        attacker = entry["attacker"]
        score = entry["final_score"]
        result = entry["result"]

        # Split combined team name to individual characters (optional enhancement)
        if "_combined" in attacker:
            team = attacker.split("_")[0]
            chars = [f"{team} Lead", f"{team} Second"]  # dummy character placeholders
        else:
            chars = [attacker]

        for char in chars:
            if char not in stats:
                stats[char] = {
                    "rDD": 0,
                    "rAST": 0,
                    "rOTD": 0
                }

            # Simulate logic
            stats[char]["rDD"] += score * 5  # arbitrary damage formula
            if result == "Victory":
                stats[char]["rOTD"] += 1
            if random.random() < 0.3:
                stats[char]["rAST"] += 1

    return stats