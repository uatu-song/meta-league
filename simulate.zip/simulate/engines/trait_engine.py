import random

class NUMBEngine:
    def __init__(self, attributes, character_name=None, base_values=None):
        self.attributes = attributes
        self.character_name = character_name
        self.base_values = base_values or self.default_base_values()

    def default_base_values(self):
        return {
            "regen_rate": 0.05,
            "base_effectiveness": 0.0,
            "base_luck_chance": 0.10
        }

    def calculate_power_rating(self):
        a = self.attributes
        return round(
            (a.get("aSTR", 0) * 0.15 +
             a.get("aSPD", 0) * 0.15 +
             a.get("aDUR", 0) * 0.15 +
             a.get("aFS", 0)  * 0.15 +
             a.get("aAM", 0)  * 0.10 +
             a.get("aLDR", 0) * 0.10 +
             a.get("aOP", 0)  * 0.10 +
             a.get("aINT", 0) * 0.10), 2)

    def compute_luck_effect(self):
        a = self.attributes
        base = self.base_values["base_luck_chance"]
        bonus = base + (a.get("aLCK", 0) * 0.01) + (a.get("aSBY", 0) * 0.005)
        return round(bonus + random.uniform(0, 0.05), 3)

    def compute_regen_bonus(self, max_hp=100):
        a = self.attributes
        rate = self.base_values["regen_rate"]
        bonus = rate * max_hp * (1 + (a.get("aDUR", 0) + a.get("aRES", 0)) / 20)
        return round(bonus, 2)

    def compute_mental_fortitude(self):
        a = self.attributes
        score = a.get("aWIL", 0) + a.get("aRES", 0) + a.get("aESP", 0)
        return round(score / 3, 2)

    def evaluate_character(self, max_hp=100):
        return {
            "character": self.character_name,
            "PowerRating": self.calculate_power_rating(),
            "LuckEffect": self.compute_luck_effect(),
            "RegenBonus": self.compute_regen_bonus(max_hp),
            "MentalFortitude": self.compute_mental_fortitude()
        }

    def evaluate_traits(self, trait_catalog, active_traits):
        results = []
        a = self.attributes

        for trait_id in active_traits:
            trait = trait_catalog.get(trait_id)
            if not trait:
                continue

            key = trait.get("formula", {}).get("key")
            expr = trait.get("formula", {}).get("expression")

            if key and expr:
                try:
                    local_vars = {k: a.get(k, 0) for k in [
                        "aSTR", "aSPD", "aDUR", "aFS", "aINT",
                        "aESP", "aRES", "aWIL", "aLDR", "aAM", "aOP", "aSBY", "aLCK"
                    ]}
                    value = eval(expr, {}, local_vars)
                    results.append({
                        "trait_id": trait_id,
                        "key": key,
                        "value": round(value, 2),
                        "type": trait.get("type"),
                        "affected_systems": trait.get("affected_systems", [])
                    })
                except Exception as e:
                    print(f"Trait evaluation failed for {trait_id}: {e}")

        return results


def apply_traits(lineups, trait_data):
    for team, members in lineups.items():
        for character in members:
            traits = trait_data.get(character, [])
            engine = NUMBEngine(attributes={}, character_name=character)  # Placeholder for real attributes
            for trait in traits:
                try:
                    # Placeholder method call — replace with real trait handlers later
                    print(f"[TRAIT] {character} activates {trait}")
                except Exception as e:
                    print(f"[ERROR] Trait '{trait}' for {character} failed: {e}")