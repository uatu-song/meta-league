# morale_engine.py

import json
import os

def adjust_team_morale(results, filepath, win_change=2, loss_change=-2):
    if os.path.exists(filepath):
        with open(filepath, "r") as f:
            morale_data = json.load(f)
    else:
        morale_data = {}

    for result in results:
        win = result["winning_team"]
        lose = result["losing_team"]
        morale_data[win] = morale_data.get(win, 50) + win_change
        morale_data[lose] = morale_data.get(lose, 50) + loss_change

    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, "w") as f:
        json.dump(morale_data, f, indent=2)