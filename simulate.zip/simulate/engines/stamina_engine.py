# stamina_engine.py

import json
import os

character_stamina = {}

DEFAULT_STAMINA = 100

def load_stamina(filepath="simulate/data/stamina.json"):
    global character_stamina
    if os.path.exists(filepath):
        with open(filepath, "r") as f:
            character_stamina = json.load(f)
    else:
        character_stamina = {}

def save_stamina(filepath="simulate/data/stamina.json"):
    with open(filepath, "w") as f:
        json.dump(character_stamina, f, indent=2)

def reduce_stamina(character_name, amount):
    current = character_stamina.get(character_name, DEFAULT_STAMINA)
    new_stamina = max(0, current - amount)
    character_stamina[character_name] = new_stamina

def get_stamina(character_name):
    return character_stamina.get(character_name, DEFAULT_STAMINA)

def apply_stamina_changes(winner, loser, lineups, filepath="simulate/data/stamina.json", base_fatigue=3, victory_bonus=1):
    load_stamina(filepath)

    for team, is_winner in [(winner, True), (loser, False)]:
        for character in lineups.get(team, []):
            fatigue = base_fatigue - victory_bonus if is_winner else base_fatigue
            reduce_stamina(character, fatigue)

    save_stamina(filepath)