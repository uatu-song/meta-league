# synergy_engine.py

def calculate_synergy_bonuses(lineups, synergy_tags, synergy_rules, environment):
    bonuses = {}

    for team_name, members in lineups.items():
        tag_counts = {}
        for char in members:
            tags = synergy_tags.get(char, [])
            for tag in tags:
                tag_counts[tag] = tag_counts.get(tag, 0) + 1

        total_bonus = 0

        for rule in synergy_rules.get("rules", []):
            if "environment_requirement" in rule and rule["environment_requirement"] != environment:
                continue

            if all(tag_counts.get(cond["tag"], 0) >= cond["value"] for cond in rule["conditions"]):
                if rule["bonus_type"] == "diceRoll":
                    total_bonus += rule["bonus_value"]

        bonuses[team_name] = {
            "total_dice_bonus": total_bonus
        }

    return bonuses