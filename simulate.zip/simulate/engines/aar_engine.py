# aar_engine.py

import os

def generate_aar(sim_logs, winning_team, losing_team, environment):
    log_summary = []
    for entry in sim_logs:
        log_summary.append(f"{entry['attacker']} engaged {entry['defender']} with a synergy bonus of {entry['synergy_bonus']}. Final score: {entry['final_score']} → {entry['result']}.")

    narrative = f"""
MISSION REPORT
--------------
Environment: {environment}
Outcome: {winning_team} defeated {losing_team}

SUMMARY LOG
{chr(10).join(log_summary)}
"""
    return narrative.strip()

def save_aar_report(text, output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w") as f:
        f.write(text)