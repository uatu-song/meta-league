# raw_output_writer.py

import os
import json
from pathlib import Path

LOG_DIR = Path("logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)

def write_turn_log(match_id, character_name, data):
    """
    Appends a character's turn data to their individual log file.
    """
    path = LOG_DIR / f"{match_id}_{character_name}_log.json"
    if path.exists():
        with open(path) as f:
            existing = json.load(f)
    else:
        existing = []

    existing.append(data)
    with open(path, "w") as f:
        json.dump(existing, f, indent=2)

def save_match_summary(match_id, match_data):
    """
    Saves the full match summary at the end of the simulation.
    """
    summary_path = LOG_DIR / f"{match_id}_summary.json"
    with open(summary_path, "w") as f:
        json.dump(match_data, f, indent=2)
