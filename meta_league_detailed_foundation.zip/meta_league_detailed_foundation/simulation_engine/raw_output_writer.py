import json
import os
import re

def sanitize_filename(name):
    """
    Replace characters that are not safe in file names (like slashes).
    """
    return re.sub(r'[^\w\-_\. ]', '_', name)

def write_turn_log(match_id, char, log_entry):
    """
    Saves individual turn logs per character during the match.
    """
    os.makedirs("logs", exist_ok=True)
    filename = f"{sanitize_filename(match_id)}_{sanitize_filename(char)}_log.json"
    path = os.path.join("logs", filename)

    with open(path, "w") as f:
        json.dump(log_entry, f, indent=2)

def save_match_summary(match_id, summary):
    """
    Saves the summary of an entire match.
    """
    os.makedirs("logs", exist_ok=True)
    path = os.path.join("logs", f"{sanitize_filename(match_id)}_summary.json")

    with open(path, "w") as f:
        json.dump(summary, f, indent=2)
