from simulation_engine.persistent_stat_log import log_team_stat

def update_morale(team, stat_block, config):
    morale_shift = 0

    if stat_block.get("rOTD", 0) > 0:
        morale_shift += 1
    if stat_block.get("rFFD", 0) > 0:
        morale_shift -= 1

    if morale_shift != 0:
        log_team_stat(team, "Morale", morale_shift, config)
