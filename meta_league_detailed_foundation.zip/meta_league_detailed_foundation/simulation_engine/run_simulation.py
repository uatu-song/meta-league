# run_simulation.py

from simulation_engine.match_processor import run_daily_match
from data_interface.data_loader import load_lineups_from_sheet, load_match_assignments, load_astats_for_characters
from config.project_config import load_config

def main():
    config = load_config()
    sheet_id = "1oYQIcQsSun6TmWooLmr00TMzXh-5ymjPwPQEgHgvVvc"

    print(f"Running simulation for {config['current_day']} of Week {config['week']}...")

    matchups = load_match_assignments(sheet_id)
    lineups = load_lineups_from_sheet(sheet_id)
    print(f"[DEBUG] Loaded lineups: {lineups}")  # ✅ This should now print

    astats_db = load_astats_for_characters()

    for match in matchups:
        run_daily_match(match, config, lineups, astats_db)

    print("\nSimulation complete.")

if __name__ == "__main__":
    main()
