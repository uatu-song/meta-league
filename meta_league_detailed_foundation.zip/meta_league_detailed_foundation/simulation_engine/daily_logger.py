from simulation_engine.persistent_stat_log import log_character_stat

def update_stamina(character, stat_block, config):
    stamina_cost = stat_block.get("rEVS", 0) + stat_block.get("rOTD", 0)
    log_character_stat(character, "Stamina", -stamina_cost, config)

def update_xp(character, stat_block, config):
    xp_gain = (
        stat_block.get("rOTD", 0) * 2 +
        stat_block.get("rAST", 0) +
        stat_block.get("rEVS", 0)
    )
    log_character_stat(character, "XP", xp_gain, config)
