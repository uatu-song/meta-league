import random

def generate_stat_block(character=None, team=None, capture_result=None):
    stat_block = {
        # Universal Stats
        "rDD": random.randint(0, 5),
        "rDS": random.randint(0, 3),
        "rOTD": random.randint(0, 6),
        "rAST": random.randint(0, 4),
        "rULT": random.randint(0, 2),
        "rLVS": random.randint(0, 1),
        "rLLS": random.randint(0, 1),
        "rDFS": random.randint(0, 2),
        "rKNB": random.randint(0, 2),
        "rCTT": random.randint(0, 3),
        "rEVS": random.randint(0, 5),
        "rFFD": random.randint(0, 1),
        "rFFI": random.randint(0, 1),

        # Operations Exclusive
        "rSNP": random.randint(0, 3),
        "rCQT": random.randint(0, 3),
        "rBRX": random.randint(0, 2),
        "rHWI": random.randint(0, 2),
        "rMOT": random.randint(0, 1),
        "rAMB": random.randint(0, 1),

        # Intelligence Exclusive
        "rMMB": random.randint(0, 3),
        "rILS": random.randint(0, 3),
        "rFE": random.randint(0, 2),
        "rDSR": random.randint(0, 2),
        "rSLP": random.randint(0, 2),
        "rRSP": random.randint(0, 2),
    }


    # Append to daily log
    if character and team:
        append_to_log(team, character, stat_block)

    # Adjust morale (only when severe events happen)
    if team:
        morale_change = 0
        morale_change -= 10 * stat_block["rFFI"]
        morale_change -= 1 * stat_block["rFFD"]
        morale_change += 3 * stat_block["rDFS"]
        morale_change += 2 * stat_block["rAST"]
        adjust_team_morale(team, morale_change)

    return stat_block
