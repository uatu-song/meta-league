def log_character_stat(character, stat_type, delta, config):
    print(f"[TRACK] {character} {stat_type} change: {delta} ({config['current_day']}, Week {config['week']})")
    # TODO: Append to file or DB

def log_team_stat(team, stat_type, delta, config):
    print(f"[TRACK] {team} {stat_type} change: {delta} ({config['current_day']}, Week {config['week']})")
    # TODO: Append to file or DB
