from pathlib import Path
from pprint import pprint
from simulation_engine.pgn_step_engine import simulate_turn_from_pgn
from simulation_engine.capture_engine import resolve_capture
from simulation_engine.stat_modifier_engine import generate_stat_block
from simulation_engine.raw_output_writer import write_turn_log, save_match_summary
from simulation_engine.daily_logger import update_stamina, update_xp
from simulation_engine.morale_tracker import update_morale
from numb_engine.stat_interpreter import calculate_power_rating
from chess_engine.pgn_generator import generate_pgn

def run_daily_match(matchup, config, lineups, astats_db):
    team_a, team_b = matchup
    print(f"Processing match: {team_a} vs {team_b}")

    team_a_chars = lineups.get(team_a, [])
    team_b_chars = lineups.get(team_b, [])
    all_characters = [(team_a, c) for c in team_a_chars] + [(team_b, c) for c in team_b_chars]

    match_id = f"{team_a}_vs_{team_b}"
    match_summary = {"team_a": team_a, "team_b": team_b, "stats": {}, "status": "in_progress"}

    for team, char in all_characters:
        pgn_moves = generate_pgn(char)
        print(f"[DEBUG] {char} PGN: {pgn_moves}")
        event_log = []

        for turn_index in range(len(pgn_moves)):
            turn = simulate_turn_from_pgn(pgn_moves, turn_index)
            if not turn.get("move"):
                break

            print(f"[DEBUG] {char} Turn {turn_index + 1}: {turn['move']}")

            char_astats = astats_db.get(char, {
                "aINT": 4, "aFS": 4, "aSPD": 4, "aLCK": 4, "aAM": 3
            })
            capture_result = resolve_capture(char_astats)
            stat_block = generate_stat_block(capture_result)
            event_log.append(stat_block)

            write_turn_log(match_id, char, {
                "turn": turn_index + 1,
                "move": turn["move"],
                "capture": capture_result,
                "stats": stat_block
            })

        combined = {}
        for e in event_log:
            for k, v in e.items():
                combined[k] = combined.get(k, 0) + v

        print(f"[DEBUG] {char} total stats: {combined}")

        match_summary["stats"][char] = combined

        update_stamina(char, combined, config)
        update_morale(team, combined, config)
        update_xp(char, combined, config)

    match_summary["status"] = "complete"
    save_match_summary(match_id, match_summary)
    return match_summary

