# capture_engine.py

import random

def resolve_capture(astats):
    """
    Simulates a probability roll based on weighted aStats.
    """
    base_roll = random.randint(1, 20)
    modifier = (
        astats.get("aINT", 0)
        + astats.get("aFS", 0)
        + astats.get("aSPD", 0)
        + astats.get("aLCK", 0)
        + int(astats.get("aAM", 0) * 0.5)
    )
    total = base_roll + modifier
    return {
        "roll": base_roll,
        "modifier": modifier,
        "total": total,
        "success": total >= 20
    }
