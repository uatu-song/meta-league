def load_lineups_from_sheet(sheet_id):
    import gspread
    from oauth2client.service_account import ServiceAccountCredentials

    SCOPE = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
    CREDENTIALS_FILE = "canvas-bot-455222-i4-dc41618510d9.json"
    creds = ServiceAccountCredentials.from_json_keyfile_name(CREDENTIALS_FILE, SCOPE)
    client = gspread.authorize(creds)

    sheet = client.open_by_key(sheet_id)
    lineup_tab = sheet.worksheet("MasterLineup")  # Make sure this is your tab name
    rows = lineup_tab.get_all_records()

    lineups = {}

    for row in rows:
        team_id = row.get("Team", "UNKNOWN")
        char_name = row.get("Nexus Being")
        position = row.get("Position")

        if position and position.strip().lower() == "bench":
            continue  # Skip bench players

        if team_id not in lineups:
            lineups[team_id] = []
        if char_name:
            lineups[team_id].append(char_name)

    return lineups
