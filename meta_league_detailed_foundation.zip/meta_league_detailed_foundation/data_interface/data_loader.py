# data_loader.py

import gspread
from oauth2client.service_account import ServiceAccountCredentials
import json

SCOPE = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
CREDENTIALS_FILE = "canvas-bot-455222-i4-a39e4a60ecfe.json"

def connect_to_sheet(sheet_id):
    creds = ServiceAccountCredentials.from_json_keyfile_name(CREDENTIALS_FILE, SCOPE)
    client = gspread.authorize(creds)
    return client.open_by_key(sheet_id)

def load_lineups_from_sheet(sheet_id):
    sheet = connect_to_sheet(sheet_id)
    tab = sheet.worksheet("MasterLineup")
    data = tab.get_all_records()

    teams = {}
    for row in data:
        team_id = row.get("Team ID") or row.get("Team") or "UNKNOWN"
        name = row.get("Nexus Being")
        position = row.get("Position")
        if team_id not in teams:
            teams[team_id] = []
        if position != "Bench":
            teams[team_id].append(name)

    return teams

def load_match_assignments(sheet_id):
    sheet = connect_to_sheet(sheet_id)
    tab = sheet.worksheet("MissionAssign")
    data = tab.get_all_records()

    matchups = []
    for row in data:
        team_a = row.get("Team A")
        team_b = row.get("Team B")
        if team_a and team_b:
            matchups.append((team_a, team_b))

    return matchups

def load_astats_for_characters():
    with open("example_data/example_character_astats.json") as f:
        return json.load(f)
