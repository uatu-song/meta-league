
import json
from pathlib import Path

TRACKER_FILE = Path("data/persistent_tracker.json")

def load_tracker():
    if not TRACKER_FILE.exists():
        return {"stamina": {}, "morale": {}, "xp": {}}
    with open(TRACKER_FILE, "r") as f:
        return json.load(f)

def save_tracker(data):
    with open(TRACKER_FILE, "w") as f:
        json.dump(data, f, indent=2)

def update_stamina(char_name, fatigue_score):
    tracker = load_tracker()
    tracker["stamina"][char_name] = tracker["stamina"].get(char_name, 100) - fatigue_score
    tracker["stamina"][char_name] = max(tracker["stamina"][char_name], 0)
    save_tracker(tracker)

def update_morale(team_id, delta):
    tracker = load_tracker()
    tracker["morale"][team_id] = tracker["morale"].get(team_id, 50) + delta
    tracker["morale"][team_id] = max(0, min(100, tracker["morale"][team_id]))
    save_tracker(tracker)

def update_xp(char_name, xp_gain):
    tracker = load_tracker()
    tracker["xp"][char_name] = tracker["xp"].get(char_name, 0) + xp_gain
    save_tracker(tracker)
