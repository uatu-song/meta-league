# Updates current team lineup data
