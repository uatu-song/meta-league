# Manages add/drop logic and eligibility
