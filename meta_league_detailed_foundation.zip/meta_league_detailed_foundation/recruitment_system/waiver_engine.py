import datetime
import gspread
from flask import Blueprint, request, jsonify
from oauth2client.service_account import ServiceAccountCredentials

# Setup blueprint
waiver_bp = Blueprint('waiver_engine', __name__)

# Google Sheets setup
SHEET_ID = 'YOUR_SHEET_ID'
WAIVER_POOL_SHEET = 'Waiver Pool'
WAIVER_CLAIMS_SHEET = 'Waiver Claims'
MASTER_ROSTER_SHEET = 'Master Roster'
STANDINGS_SHEET = 'Team Standings'

scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('canvas-bot-455222-i4-a39e4a60ecfe.json', scope)
client = gspread.authorize(creds)
sheet = client.open_by_key(SHEET_ID)

def get_sheet(name):
    return sheet.worksheet(name)

@waiver_bp.route('/api/drop_character', methods=['POST'])
def drop_character():
    data = request.json
    character = data['character']
    team = data['team']
    drop_time = datetime.datetime.now()
    expiry_time = drop_time + datetime.timedelta(hours=24)

    waiver_pool = get_sheet(WAIVER_POOL_SHEET)
    waiver_pool.append_row([character, team, str(drop_time), str(expiry_time), "TRUE", "FALSE", "", ""])

    # Update master roster (assumes character is in column A and team in column B)
    master = get_sheet(MASTER_ROSTER_SHEET)
    records = master.get_all_records()
    for i, row in enumerate(records, start=2):
        if row['Character'] == character:
            master.update_cell(i, 2, 'On Waivers')  # Update team column
            break

    return jsonify({"status": "success", "message": f"{character} placed on waivers by {team}."})

@waiver_bp.route('/api/claim_waiver', methods=['POST'])
def claim_waiver():
    data = request.json
    character = data['character']
    team = data['team']
    timestamp = datetime.datetime.now()

    claims_sheet = get_sheet(WAIVER_CLAIMS_SHEET)
    claims_sheet.append_row([
        f"WC{int(timestamp.timestamp())}",
        character,
        team,
        str(timestamp),
        "",  # Waiver expiry will be pulled during resolution
        "Pending",
        "",
        ""
    ])

    return jsonify({"status": "success", "message": f"{team} submitted a claim for {character}."})

def resolve_waivers():
    waiver_pool = get_sheet(WAIVER_POOL_SHEET)
    claims_sheet = get_sheet(WAIVER_CLAIMS_SHEET)
    standings = get_sheet(STANDINGS_SHEET).get_all_records()
    standings_order = {team['Team Name']: team['Ranking (1 = lowest)'] for team in standings}

    pool = waiver_pool.get_all_records()
    now = datetime.datetime.now()

    for i, row in enumerate(pool, start=2):
        if row['On Waivers?'] == 'TRUE':
            expiry = datetime.datetime.fromisoformat(row['Waiver Expiry'])
            if now >= expiry:
                character = row['Character']
                claims = claims_sheet.get_all_records()
                relevant_claims = [c for c in claims if c['Character'] == character and c['Status'] == 'Pending']
                if relevant_claims:
                    sorted_claims = sorted(relevant_claims, key=lambda c: standings_order.get(c['Claiming Team'], 999))
                    winner = sorted_claims[0]['Claiming Team']
                    # Update Master Roster and team sheet manually here

                    for j, claim in enumerate(claims, start=2):
                        if claim['Character'] == character:
                            if claim['Claiming Team'] == winner:
                                claims_sheet.update_cell(j, 6, 'Awarded')
                                claims_sheet.update_cell(j, 7, str(now))
                                claims_sheet.update_cell(j, 8, f"Awarded to {winner}")
                            else:
                                claims_sheet.update_cell(j, 6, 'Denied')
                                claims_sheet.update_cell(j, 7, str(now))
                                claims_sheet.update_cell(j, 8, f"Lost to {winner}")

                    waiver_pool.update_cell(i, 5, 'FALSE')
                    waiver_pool.update_cell(i, 6, 'TRUE')
                    waiver_pool.update_cell(i, 7, winner)
                    waiver_pool.update_cell(i, 8, "Claim resolved")

                else:
                    waiver_pool.update_cell(i, 5, 'FALSE')
                    waiver_pool.update_cell(i, 6, 'FALSE')
                    waiver_pool.update_cell(i, 7, '')
                    waiver_pool.update_cell(i, 8, "No claims submitted")
