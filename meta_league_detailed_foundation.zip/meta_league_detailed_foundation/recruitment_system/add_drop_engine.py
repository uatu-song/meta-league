import datetime
from flask import Blueprint, request, jsonify
from free_agent_handler import is_eligible_add, is_eligible_drop
from roster_updater import add_character_to_team, remove_character_from_team, is_roster_within_limits

add_drop_bp = Blueprint('add_drop_engine', __name__)

@add_drop_bp.route('/api/confirm_add_drop', methods=['POST'])
def confirm_add_drop():
    data = request.get_json()
    password = data.get('password')
    moves = data.get('moves', [])

    results = []
    for move in moves:
        character = move['character']
        action = move['action']
        team = get_team_by_password(password)  # Implement this securely

        if not team:
            return jsonify({"status": "error", "message": "Invalid password."})

        if action == "Add":
            if not is_eligible_add(character):
                results.append({"character": character, "result": "Cannot add—already on a team or locked."})
                continue

            if not is_roster_within_limits(team):
                results.append({"character": character, "result": "Roster full. Drop someone first."})
                continue

            add_character_to_team(team, character)
            results.append({"character": character, "result": "Added successfully."})

        elif action == "Drop":
            if not is_eligible_drop(character, team):
                results.append({"character": character, "result": "Cannot drop—character not on your team."})
                continue

            remove_character_from_team(team, character)
            results.append({"character": character, "result": "Dropped successfully."})

    return jsonify({"status": "success", "message": "Moves processed.", "details": results})
