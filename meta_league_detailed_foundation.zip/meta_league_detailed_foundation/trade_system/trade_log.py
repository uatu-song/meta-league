# Logs all completed transactions
