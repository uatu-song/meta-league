# stat_interpreter.py

def calculate_power_rating(astats):
    """
    Calculates a character’s Power Rating using weighted attribute values.
    """
    weights = {
        "aINT": 1.4, "aEND": 1.0, "aSTR": 1.2, "aSTA": 1.0,
        "aEP": 1.2, "aSPD": 1.1, "aFS": 1.3, "aWIL": 1.1,
        "aRES": 1.0, "aLDR": 1.3, "aESP": 1.3, "aOP": 1.5,
        "aAM": 0.5, "aSTB": 1.0, "aLCK": 1.2
    }

    return round(sum(astats.get(stat, 0) * weight for stat, weight in weights.items()), 2)
