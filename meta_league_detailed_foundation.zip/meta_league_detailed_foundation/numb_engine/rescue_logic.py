def attempt_rescue(ko_events, teammate_positions, abilities):
    """
    Determines if any KO'd characters were rescued by nearby allies.
    Returns a dictionary of character names with 'rescued': True/False.
    """
    rescues = {}
    for ko_char, pos in ko_events.items():
        rescued = False
        for teammate, t_pos in teammate_positions.items():
            if "rescue" in abilities.get(teammate, []) and abs(pos[0] - t_pos[0]) <= 1 and abs(pos[1] - t_pos[1]) <= 1:
                rescued = True
                break
        rescues[ko_char] = {"rescued": rescued}
    return rescues
