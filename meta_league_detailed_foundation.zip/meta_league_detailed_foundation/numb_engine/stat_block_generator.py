def generate_stat_block(simulation_data, character_metadata):
    """
    Converts simulation events into a structured stat block per character.
    Returns a dictionary of rStats keyed by character name.
    """
    stat_blocks = {}
    for character, events in simulation_data.items():
        stat_blocks[character] = {
            "rDD": 0,
            "rAST": 0,
            "rOTD": 0,
            # ... initialize all rStats
        }
        # TODO: Apply stat interpretation logic here
    return stat_blocks
