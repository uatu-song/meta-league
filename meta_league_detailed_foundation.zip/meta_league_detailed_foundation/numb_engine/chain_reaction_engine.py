# Manages cascading effects triggered by stat events
