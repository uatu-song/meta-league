import csv

def save_to_csv(data, filename):
    """
    Saves character data (XP, stamina, etc.) to a CSV file.
    """
    with open(filename, mode='w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=data[0].keys())
        writer.writeheader()
        for row in data:
            writer.writerow(row)
