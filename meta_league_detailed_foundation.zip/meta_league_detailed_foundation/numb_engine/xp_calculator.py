# Tracks XP progression and stat scaling
