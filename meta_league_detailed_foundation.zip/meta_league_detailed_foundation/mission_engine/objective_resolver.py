# Determines win conditions and objective scoring
