# Chooses daily mission types and target sectors
