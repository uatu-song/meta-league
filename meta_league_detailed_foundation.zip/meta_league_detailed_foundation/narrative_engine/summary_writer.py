def compile_summary(team_stats, mission_outcome):
    highlights = {
        "Top Performing Team Summary": f"{team_stats.get('team_name')} showed strong cohesion.",
        "MVP Highlights": "Key operatives led the charge with decisive actions.",
        "Tactical Highlights": "Team executed flanks and defended positions smartly.",
        "Close Calls": "Several near-KOs avoided through synergy or skill.",
        "Advisor Reflections": "Expectations moving into the next day are high."
    }
    return highlights
