def format_stat_name(stat_code):
    return stat_code.replace("r", "").upper()
