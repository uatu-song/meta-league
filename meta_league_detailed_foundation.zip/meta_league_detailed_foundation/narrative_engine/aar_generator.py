from .sitrep_writer import generate_log
from .advisor_commentary import get_quote
from .summary_writer import compile_summary

def generate_aar(team_stats, mission_outcome, advisor_archetype, morale_data, grid_positions):
    sitrep = generate_log(team_stats, grid_positions)
    advisor_quote = get_quote(advisor_archetype, mission_outcome)
    summary = compile_summary(team_stats, mission_outcome)

    aar = {
        "team": team_stats.get("team_name"),
        "day": team_stats.get("day"),
        "outcome": mission_outcome,
        "morale": morale_data,
        "sitrep": sitrep,
        "advisor": {
            "name": advisor_archetype,
            "quote": advisor_quote
        },
        "box_score": team_stats.get("box_score"),
        "grid_positions": grid_positions,
        "summary": summary
    }

    return aar
