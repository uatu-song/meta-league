AAR_TEMPLATES = {
    "Idealist": {
        "Victory": "We did what we came to do. Against all odds, we held the line — and saved lives.",
        "Draw": "We got through... but at what cost? We can't afford to lose sight of who we are.",
        "Failure": "They were counting on us. We didn’t just lose the mission — we lost a piece of ourselves."
    },
    "Strategist": {
        "Victory": "Mission accomplished. Objectives neutralized. We’ll carry momentum into the next op.",
        "Draw": "Tactically sound, but incomplete. We’ll adapt and reinforce where needed.",
        "Failure": "A missed opportunity. Reassess squad composition and threat models."
    }
    # Add others as needed
}

def get_quote(archetype: str, outcome: str) -> str:
    return AAR_TEMPLATES.get(archetype, {}).get(outcome, "No commentary available.")
