def calculate_morale(previous_morale, mission_outcome, deaths=0, rescues=0, ff_penalties=0):
    """
    Adjusts team morale after a mission.
    Returns morale dict including modifier and note for AAR injection.
    """
    morale = previous_morale
    note = ""
    if mission_outcome == "Victory":
        morale += 5
        note = "Victory uplifted team spirit."
    elif mission_outcome == "Failure":
        morale -= 10
        note = "Defeat lowered confidence."
    morale -= (deaths * 5)
    morale += (rescues * 3)
    morale -= ff_penalties

    modifier = "positive" if morale >= 70 else "neutral" if morale >= 40 else "shaken" if morale >= 20 else "broken"
    return {
        "team_morale": max(0, morale),
        "modifier": modifier,
        "note": note
    }
