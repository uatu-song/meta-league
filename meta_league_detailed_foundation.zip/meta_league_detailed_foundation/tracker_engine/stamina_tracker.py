def update_stamina(current_stamina, stat_blocks, role_map=None, rested_characters=None):
    """
    Applies stamina cost based on character effort level and role intensity.
    Adds passive overnight recovery. Flags exhausted characters.

    Parameters:
    - current_stamina: dict of character stamina before the mission
    - stat_blocks: dict of rStat totals per character
    - role_map: dict of roles per character (e.g., FL, RG, GO)
    - rested_characters: optional set of characters who did not participate

    Returns:
    - updated_stamina: dict with stamina values after cost and recovery
    - fatigue_flags: dict with any character flagged as 'Fatigued' or 'Exhausted'
    """

    updated_stamina = {}
    fatigue_flags = {}

    for name, base_stam in current_stamina.items():
        rStat_total = sum(stat_blocks.get(name, {}).values())
        role = role_map.get(name, "RG") if role_map else "RG"
        is_rested = name in rested_characters if rested_characters else False

        # STAMINA COST LOGIC
        if is_rested:
            cost = 0
        elif rStat_total < 30:
            cost = 10
        elif rStat_total < 60:
            cost = 18
        elif rStat_total < 100:
            cost = 24
        else:
            cost = 28  # Heavy drain for extreme activity

        # Role adjustment
        if role == "FL":
            cost += 2
        elif role == "GO":
            cost -= 2

        # RECOVERY LOGIC
        if is_rested:
            recovery = 20
        elif cost <= 12:
            recovery = 10
        else:
            recovery = 5

        # Net stamina change
        stamina_after = max(0, base_stam - cost + recovery)
        updated_stamina[name] = stamina_after

        # FATIGUE FLAGS
        if stamina_after == 0:
            fatigue_flags[name] = "Exhausted"
        elif stamina_after < 20:
            fatigue_flags[name] = "Fatigued"

    return updated_stamina, fatigue_flags
