# load_config function for project_config.json

import json
from pathlib import Path

def load_config():
    config_path = Path(__file__).parent.parent / "config" / "project_config.json"
    with open(config_path) as f:
        return json.load(f)
