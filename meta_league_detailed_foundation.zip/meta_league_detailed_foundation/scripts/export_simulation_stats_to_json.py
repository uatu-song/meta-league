# scripts/export_simulation_stats_to_json.py

import os
import json

LOGS_DIR = "logs"
OUTPUT_PATH = "public/data/simulation_results.json"

def extract_stats_from_log(file_path):
    with open(file_path, "r") as f:
        try:
            log_data = json.load(f)
            return log_data.get("stats", {})
        except Exception as e:
            print(f"[ERROR] Failed to parse {file_path}: {e}")
            return {}

def compile_simulation_data():
    if not os.path.exists(LOGS_DIR):
        print(f"[ERROR] Logs folder not found: {LOGS_DIR}")
        return []

    compiled_results = []

    for filename in os.listdir(LOGS_DIR):
        if not filename.endswith("_log.json"):
            continue

        parts = filename.replace("_log.json", "").split("_")
        if len(parts) < 3:
            continue

        match_id = f"{parts[0]}_{parts[1]}"
        character = " ".join(parts[2:])
        file_path = os.path.join(LOGS_DIR, filename)

        stats = extract_stats_from_log(file_path)
        if stats:
            compiled_results.append({
                "match_id": match_id,
                "character": character,
                "stats": stats
            })

    return compiled_results

def export_to_json(data):
    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, "w") as f:
        json.dump(data, f, indent=2)
    print(f"✅ Exported {len(data)} simulation results to {OUTPUT_PATH}")

if __name__ == "__main__":
    results = compile_simulation_data()
    export_to_json(results)
