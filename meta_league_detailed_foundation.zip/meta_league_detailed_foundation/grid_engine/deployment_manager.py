# Manages team placements across grid sectors
