# Maps local grid positions to global 100x100 space
