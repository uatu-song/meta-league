# Names, labels, and mission dependencies for sectors
