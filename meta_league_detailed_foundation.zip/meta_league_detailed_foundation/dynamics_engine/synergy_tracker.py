# Evaluates character synergy outcomes
