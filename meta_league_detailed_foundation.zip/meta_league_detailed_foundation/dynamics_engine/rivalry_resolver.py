# Detects tension or ally loyalty moments
