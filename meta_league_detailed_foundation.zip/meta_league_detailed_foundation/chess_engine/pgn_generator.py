import chess
import chess.engine

STOCKFISH_PATH = "/usr/local/bin/stockfish"

def generate_pgn(character_name, num_moves=6):
    """
    Simulates a short PGN stream representing this character’s tactical flow.
    Returns a list of moves in algebraic notation.
    """
    board = chess.Board()
    move_list = []

    try:
        with chess.engine.SimpleEngine.popen_uci(STOCKFISH_PATH) as engine:
            for _ in range(num_moves):
                if board.is_game_over():
                    break
                result = engine.play(board, chess.engine.Limit(time=0.1))
                
                # FIX: capture SAN before making the move
                move_san = board.san(result.move)
                board.push(result.move)

                move_list.append(move_san)

    except FileNotFoundError:
        print(f"[ERROR] Stockfish not found at {STOCKFISH_PATH}")
    except Exception as e:
        print(f"[ERROR] {e}")

    return move_list
