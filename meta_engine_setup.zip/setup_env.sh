
#!/usr/bin/env bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
echo "✅ Virtualenv ready.  Run ./scripts/run_matchday.py to simulate."
