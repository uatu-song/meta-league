
# META League Tactical Narrative Chess Engine

This repository powers an 8 v 8 superhero simulation where every hero plays
a miniature chess game.  Move quality is decided by Stockfish *plus dice*,
attributes drive search depth / roll bonuses, and cross‑board synergy is
detected each ply.

---

## 1 │ Prerequisites

* **Python 3.9+**
* **Stockfish** binary on your `PATH`  
  (`brew install stockfish` | `apt install stockfish`)
* A virtualenv (recommended)

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## 2 │ Directory layout

```
engine/                ← core modules (event_bus, combat_loop, etc.)
traits/                ← trait implementations
schemas/               ← JSON‑Schema definitions
data/                  ← line‑ups, roster CSVs, etc.
output/                ← PGNs & JSONL box‑scores
scripts/               ← CLI wrappers and cron utilities
```

## 3 │ Running a match‑day

```bash
./scripts/run_matchday.py   --lineup data/lineups/2025‑04‑21.json   --out    output
```

* Writes one **box‑score JSONL** per match in `output/YYYY‑MM‑DD/`
* Updates stamina and morale, then calls nightly regeneration.

## 4 │ Adding a new trait

1. Create a class in `traits/your_trait.py` inheriting `TraitBase`.  
2. Add the dotted path to `trait_catalog.json`.
3. TraitEngine auto‑loads it on next run.

## 5 │ Nightly cron

```
0 22 * * *  /path/to/.venv/bin/python scripts/nightly_tick.py
```

`nightly_tick` regenerates stamina, rolls over week/day counters, and cleans
old PGNs.

## 6 │ Validation

All outputs are validated against the JSON‑Schema files in `schemas/` using
`jsonschema`.  CI will fail if any box‑score or daily state snapshot is invalid.

---

Generated 2025-04-21.
